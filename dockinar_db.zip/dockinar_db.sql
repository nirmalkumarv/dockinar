-- phpMyAdmin SQL Dump
-- version 3.5.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 30, 2015 at 01:02 PM
-- Server version: 5.6.12
-- PHP Version: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dockinar_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `do_category`
--

CREATE TABLE IF NOT EXISTS `do_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `rec_status` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `do_category`
--

INSERT INTO `do_category` (`id`, `name`, `description`, `created_date`, `modified_date`, `rec_status`) VALUES
(1, 'Hosting', 'Hosting', '2015-05-09 17:09:47', '2015-05-09 17:09:47', 1),
(2, 'Cloud Computing', 'Cloud Computing', '2015-05-09 17:09:57', NULL, 1),
(3, 'Photography', 'Photography', '2015-05-09 17:10:01', NULL, 1),
(4, 'NOSQL', 'NOSQL', '2015-05-09 17:10:05', NULL, 1),
(5, 'Business Intelligence', 'Business Intelligence - Reporting', '2015-05-09 17:42:53', '2015-05-09 17:42:53', 1),
(6, 'Technology', 'Technology', '2015-05-09 17:10:15', NULL, 1),
(7, 'Server Administration', 'Server Administration', '2015-05-09 17:10:21', NULL, 1),
(8, 'Software Development', 'Software Development', '2015-05-09 17:10:26', NULL, 1),
(9, 'Mobile Development', 'Mobile Development', '2015-05-09 17:10:32', NULL, 1),
(10, 'Tutorials', 'Tutorials', '2015-05-09 17:10:38', NULL, 1),
(11, 'Project Management', 'Project Management', '2015-05-09 17:10:50', NULL, 1),
(12, 'Automated Testing', 'Automated Testing', '2015-05-09 17:52:54', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `do_developer_keys`
--

CREATE TABLE IF NOT EXISTS `do_developer_keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dev_user_id` int(11) NOT NULL,
  `api_key` varchar(100) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `rec_status` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dev_user_id` (`dev_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `do_docklet`
--

CREATE TABLE IF NOT EXISTS `do_docklet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `webinar_id` int(11) NOT NULL,
  `sms_notified` tinyint(4) DEFAULT NULL,
  `sms_subscribed` tinyint(4) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `rec_status` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `webinar_id` (`webinar_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `do_organizers`
--

CREATE TABLE IF NOT EXISTS `do_organizers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text,
  `logo_name` varchar(100) NOT NULL,
  `website_url` varchar(200) DEFAULT NULL,
  `owner_user_id` int(11) DEFAULT NULL,
  `webinar_series_url` varchar(200) DEFAULT NULL,
  `default_category_id` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `rec_status` tinyint(4) DEFAULT NULL,
  `org_code` varchar(45) DEFAULT NULL,
  `fetch_enabled` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `do_organizers`
--

INSERT INTO `do_organizers` (`id`, `name`, `description`, `logo_name`, `website_url`, `owner_user_id`, `webinar_series_url`, `default_category_id`, `created_date`, `modified_date`, `rec_status`, `org_code`, `fetch_enabled`) VALUES
(1, 'Accenture', 'Accenture', 'img.jpg', 'www.accenture.com/', NULL, 'http://sauceio.com/index.php/tag/webinar/', 6, '2015-05-30 18:09:02', '2015-05-30 18:09:02', 1, 'accenture', 0),
(2, 'Adobe', 'Adobe', 'adobe.jpg', 'https://www.adobe.com', NULL, 'https://www.adobe.com/cfusion/event/index.cfm?event=list&type=eseminar', 1, '2015-05-30 18:09:14', '2015-05-30 18:09:14', 1, '', 1),
(3, 'Amazon', 'Amazon', 'amazon_logo.png', 'http://www.amazon.com/', NULL, 'http://aws.amazon.com/about-aws/events/', 1, '2015-05-10 11:02:16', '2015-05-10 11:02:16', 1, 'amazon', 1),
(4, 'Appery.io', 'Appery.io', 'img.jpg', 'https://appery.io/', NULL, 'https://blog.appery.io/category/events/webinar/', 1, '2015-05-30 18:11:27', '2015-05-30 18:11:27', 1, 'cloudbees', 1),
(5, 'CloudBees', 'CloudBees', 'cloudBees.jpg', 'https://www.cloudbees.com', NULL, 'https://www.cloudbees.com/event-type/webinar', 1, '2015-05-10 11:03:22', '2015-05-10 11:03:22', 1, '', 1),
(6, 'CollabNet', 'CollabNet', 'img.jpg', 'www.collab.net/', NULL, 'http://www.collab.net/resources/webinars', 1, '2015-05-30 18:14:15', '2015-05-30 18:14:15', 1, 'collabnet', 1),
(7, 'DZone', 'DZone', 'img.jpg', 'www.dzone.com/', NULL, '', 1, '2015-05-30 18:16:39', '2015-05-30 18:16:39', 1, 'dzone', 0),
(8, 'Google', 'Google', 'img.jpg', 'www.google.com/', NULL, 'https://www.google.co.in/ads/experienced/webinars.html', 1, '2015-05-30 18:22:29', '2015-05-30 18:22:29', 1, '', 0),
(9, 'IBM', 'IBM', 'img.jpg', 'https://www.ibm.com/', NULL, 'http://securityintelligence.com/events/', 1, '2015-05-10 08:45:05', '2015-05-10 08:45:05', 1, NULL, 1),
(10, 'Intel Software', 'Intel Software', 'img.jpg', 'www.intel.com', NULL, NULL, NULL, '2015-05-09 15:18:13', NULL, 1, NULL, 1),
(11, 'InterTech', 'InterTech', 'img.jpg', NULL, NULL, 'http://www.intertech.com/Free-Developer-Training/UserGroups/OxygenBlast', 1, '2015-05-10 07:50:45', '2015-05-10 07:50:45', 1, NULL, 1),
(12, 'Microsoft', 'Microsoft', 'microsoft.png', 'https://www.microsoft.com/', NULL, '', 1, '2015-05-10 11:05:46', '2015-05-10 11:05:46', 1, '', 1),
(13, 'MongoDB Inc', 'MongoDB Inc', 'mongodb-logo-web.png', 'http://mongodb.com/', NULL, 'http://www.mongodb.com/webinars', 1, '2015-05-10 11:06:15', '2015-05-10 11:06:15', 1, 'mongodb', 1),
(14, 'NewRelic', 'NewRelic', 'img.jpg', NULL, NULL, 'http://newrelic.com/resources/webinars', 1, '2015-05-30 17:53:10', '2015-05-30 17:53:10', 1, 'new-relic', 1),
(15, 'Nokia', 'Nokia', 'img.jpg', NULL, NULL, NULL, NULL, '2015-05-09 15:18:13', NULL, 1, NULL, 1),
(16, 'OpenShift', 'OpenShift', 'img.jpg', NULL, NULL, 'https://blog.openshift.com/red-hat-webinar-series-getting-started-with-enterprise-paas/', 1, '2015-05-10 07:52:30', '2015-05-10 07:52:30', 1, NULL, 1),
(17, 'Rackspace', 'Rackspace', 'img.jpg', NULL, NULL, NULL, NULL, '2015-05-09 15:18:13', NULL, 1, NULL, 1),
(18, 'SanDisk', 'SanDisk', 'img.jpg', 'www.sandisk.com/', NULL, NULL, NULL, '2015-05-09 15:18:13', NULL, 1, NULL, 1),
(19, 'TechGig', 'TechGig', 'img.jpg', 'www.techgig.com/', NULL, 'http://www.techgig.com/expert-speak', 1, '2015-05-10 07:52:00', '2015-05-10 07:52:00', 1, NULL, 1),
(20, 'Xamarin', 'Xamarin', 'img.jpg', NULL, NULL, 'https://developer.xamarin.com/videos/', 1, '2015-05-10 07:52:51', '2015-05-10 07:52:51', 1, NULL, 1),
(21, 'InfoQ', 'InfoQ', 'img.jpg', 'www.infoq.com', NULL, 'http://www.infoq.com/presentations/', 1, '2015-05-10 07:53:15', '2015-05-10 07:53:15', 1, NULL, 1),
(22, 'Linux', 'Linux', 'linux.jpg', 'https://www.linux.com/', NULL, 'http://training.linuxfoundation.org/free-linux-training/linux-training-videos', 1, '2015-05-10 07:53:59', '2015-05-10 07:53:59', 1, NULL, 1),
(23, 'Couchbase', 'Couchbase', 'img.jpg', 'www.couchbase.com/', NULL, 'http://www.couchbase.com/nosql-resources/webinar/recorded', 1, '2015-05-10 15:59:29', '2015-05-10 15:59:29', 1, 'couchbase', 1),
(24, 'Oracle', 'Oracle', 'oracle.png', 'www.oracle.com/', NULL, 'http://www.oracle.com/technetwork/server-storage/solaris11/overview/webinar-series-1563626.html', 1, '2015-05-10 11:06:35', '2015-05-10 11:06:35', 1, '', 1),
(25, 'Dell', 'Dell', 'dell.png', 'https://www.dell.com/', NULL, 'http://en.community.dell.com/techcenter/networking/w/wiki/4427.dell-networking-webinar-series', 1, '2015-05-10 11:03:47', '2015-05-10 11:03:47', 1, '', 1),
(26, 'Cisco', 'Cisco', 'cisco.jpg', 'www.cisco.com', NULL, 'http://www.cisco.com/web/learning/le21/learning_events_home.html', 1, '2015-05-10 11:02:56', '2015-05-10 11:02:56', 1, '', 1),
(27, 'Cloud Computing', 'Cloud Computing', 'img.jpg', NULL, NULL, 'http://www.gartner.com/technology/webinars/cloud-computing.jsp', 1, '2015-05-10 08:02:42', '2015-05-10 08:02:42', 1, 'cloud', 1),
(28, 'Jaspersoft', 'Jaspersoft', 'jaspersoft.jpg', 'https://www.jaspersoft.com/', NULL, '', 5, '2015-05-10 11:04:27', '2015-05-10 11:04:27', 1, '', 1),
(29, 'Talend', 'Talend', 'Talend.jpg', 'www.talend.com', NULL, '', 5, '2015-05-10 11:07:10', '2015-05-10 11:07:10', 1, '', 1),
(30, 'MarkLogic', 'MarkLogic', 'marklogic.jpg', 'www.marklogic.com', NULL, 'http://www.marklogic.com/events/', 1, '2015-05-10 08:03:13', '2015-05-10 08:03:13', 1, NULL, 1),
(31, 'Pluralsight', 'Pluralsight', 'pluralsight.png', 'http://www.pluralsight.com/', NULL, 'http://blog.pluralsight.com/webinars', 1, '2015-05-30 18:25:08', '2015-05-30 18:25:08', 1, '', 1),
(32, 'SauceLab', 'SauceLab', 'sauce-labs-logo.png', 'https://saucelabs.com/', NULL, 'http://sauceio.com/index.php/tag/webinar/', 12, '2015-05-10 11:01:40', '2015-05-10 11:01:40', 1, 'sauce', 1);

-- --------------------------------------------------------

--
-- Table structure for table `do_twilio_sms_logs`
--

CREATE TABLE IF NOT EXISTS `do_twilio_sms_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `webinar_id` int(11) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `rec_status` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `webinar_id` (`webinar_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `do_users`
--

CREATE TABLE IF NOT EXISTS `do_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `do_username` varchar(100) DEFAULT NULL,
  `do_password` varchar(50) DEFAULT NULL,
  `do_email_id` varchar(100) DEFAULT NULL,
  `mobile_no` varchar(50) DEFAULT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `is_speaker` tinyint(1) DEFAULT NULL,
  `is_developer` tinyint(1) DEFAULT NULL,
  `is_organizer` tinyint(1) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `rec_status` tinyint(4) DEFAULT NULL,
  `is_sms_subscribed` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `do_users`
--

INSERT INTO `do_users` (`id`, `do_username`, `do_password`, `do_email_id`, `mobile_no`, `firstname`, `lastname`, `is_speaker`, `is_developer`, `is_organizer`, `created_date`, `modified_date`, `rec_status`, `is_sms_subscribed`) VALUES
(1, NULL, 'Surend', 'Surend', NULL, 'Surend', 'Surend', 0, 1, 1, '2015-05-10 10:50:08', '2015-05-10 10:50:08', 1, 0),
(2, NULL, NULL, 'lkjklh', NULL, 'kjhjh', 'kss', NULL, NULL, NULL, '2015-05-10 06:23:23', NULL, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `do_user_activity`
--

CREATE TABLE IF NOT EXISTS `do_user_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `act_dt` datetime DEFAULT NULL,
  `act_type` varchar(100) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `reference_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `do_webinars`
--

CREATE TABLE IF NOT EXISTS `do_webinars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) DEFAULT NULL,
  `description` text,
  `webinar_date` date DEFAULT NULL,
  `webinar_time` time DEFAULT NULL,
  `webinar_datetime` datetime DEFAULT NULL,
  `speaker_name` varchar(100) DEFAULT NULL,
  `speaker_user_id` int(11) DEFAULT NULL,
  `speaker_desc` text,
  `webinar_timezone` varchar(10) DEFAULT NULL,
  `org_id` int(11) DEFAULT NULL,
  `webinar_url` varchar(250) DEFAULT NULL,
  `webinar_reg_url` text,
  `webinar_source` varchar(100) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `rec_status` tinyint(4) DEFAULT NULL,
  `speaker_desig` varchar(100) DEFAULT NULL,
  `is_tweeted` tinyint(4) DEFAULT NULL,
  `recorded_url` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `webinar_url_UNIQUE` (`webinar_url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=136 ;

--
-- Dumping data for table `do_webinars`
--

INSERT INTO `do_webinars` (`id`, `title`, `description`, `webinar_date`, `webinar_time`, `webinar_datetime`, `speaker_name`, `speaker_user_id`, `speaker_desc`, `webinar_timezone`, `org_id`, `webinar_url`, `webinar_reg_url`, `webinar_source`, `created_date`, `modified_date`, `rec_status`, `speaker_desig`, `is_tweeted`, `recorded_url`) VALUES
(1, 'Decreasing False Positives in Automated Testing ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 32, 'http://sauceio.com/index.php/2015/03/decreasing-false-positives-in-automated-testing-webinar/', 'http://sauceio.com/index.php/2015/03/decreasing-false-positives-in-automated-testing-webinar/', NULL, '2015-05-11 14:35:32', '2015-05-11 14:35:32', 1, NULL, 1, NULL),
(2, 'Continuous Testing in Practice ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 32, 'http://sauceio.com/index.php/2015/02/continuous-testing-in-practice-webinar-2/', 'http://sauceio.com/index.php/2015/03/decreasing-false-positives-in-automated-testing-webinar/', NULL, '2015-05-09 20:23:02', NULL, 1, NULL, 0, NULL),
(3, 'Mobile Testing Talk: What&#8217;s New With Appium ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 32, 'http://sauceio.com/index.php/2014/12/mobile-testing-talk-whats-new-with-appium-webinar/', 'http://sauceio.com/index.php/2015/03/decreasing-false-positives-in-automated-testing-webinar/', NULL, '2015-05-10 03:39:43', '2015-05-10 03:39:43', 1, NULL, 0, NULL),
(4, 'How Yahoo! Mail Transformed Its Functional Testing + Continuous Delivery Process ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 32, 'http://sauceio.com/index.php/2014/10/yahoo-mail-functional-testing-and-continuous-delivery-process-webinar/', 'http://sauceio.com/index.php/2015/03/decreasing-false-positives-in-automated-testing-webinar/', NULL, '2015-05-10 14:07:27', '2015-05-10 14:07:27', 1, NULL, 0, NULL),
(5, 'Cloud9 + Sauce Labs Integration: Learn How It Works ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 32, 'http://sauceio.com/index.php/2014/08/cloud9-sauce-labs-integration-learn-how-it-works-webinar/', 'http://sauceio.com/index.php/2015/03/decreasing-false-positives-in-automated-testing-webinar/', NULL, '2015-05-10 14:07:53', '2015-05-10 14:07:53', 1, NULL, 0, NULL),
(6, 'Recap: Continuous Testing in the Cloud ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 32, 'http://sauceio.com/index.php/2014/06/recap-continuous-testing-in-the-cloud-webinar/', 'http://sauceio.com/index.php/2015/03/decreasing-false-positives-in-automated-testing-webinar/', NULL, '2015-05-10 14:08:56', '2015-05-10 14:08:56', 1, NULL, 0, NULL),
(7, 'Recap: Best Practices in Mobile CI ', NULL, NULL, NULL, '2015-05-12 00:00:00', NULL, NULL, NULL, NULL, 32, 'http://sauceio.com/index.php/2015/04/recap-best-practices-in-mobile-ci-webinar/', 'http://sauceio.com/index.php/2015/03/decreasing-false-positives-in-automated-testing-webinar/', NULL, '2015-05-09 20:23:02', NULL, 1, NULL, 0, NULL),
(8, 'AngularJS 2.0: What you need to know', 'Are you ready for AngularJS 2.0? How will this potentially major overhaul impact you and your business? In this webinar, Pluralsight author Joe Eames will cover what’s different with 2.0, what’s staying the same and how you can begin experimenting with it today.', '2015-05-14', '10:00:00', NULL, 'Joe ', NULL, 'Joe began his love of programming on an Apple III in BASIC. Although his preferred language is JavaScript, he has worked professionally with just about every major Microsoft language. He is currently a consultant and full time author for Pluralsight. Joe has always had a strong interest in education, and has worked both full and part time as a technical teacher for over ten years. He is a frequent blogger and speaker, organizer of ng-conf, the AngularJS conference (www.ng-conf.org), and a panelist on the JavaScript Jabber podcast (http://javascriptjabber.com/)', NULL, 31, 'https://get.pluralsight.com/AngularJS-20-What-you-need-to-know_Registration-Page', 'https://get.pluralsight.com/AngularJS-20-What-you-need-to-know_Registration-Page', NULL, '2015-05-10 13:55:13', '2015-05-10 13:55:13', 1, NULL, 0, NULL),
(12, ' Managing Your Mission Critical App - Ensuring Zero Downtime', 'As a Database Administrator, you know just how stressful it can be to ensure your system is never down. MongoDB seeks to solve this problem by ensuring that no matter which database task you''re performing, you maintain high availability.\r\n\r\nThis webinar will cover how to ensure zero downtime when managing a MongoDB cluster. We''ll start by covering replica sets and then dive into automated software upgrades, and describe various deployment topologies including globally deployed clusters over multiple continents. We will also describe how MongoDB helps you scale on demand without requiring downtime, by automatically redistributing data across the newly provisioned hardware.\r\n\r\nTopics Covered Include:\r\n\r\nHigh Availability through Replica Sets\r\nAutomated Upgrades\r\nBackups\r\nScaling - Sharding\r\nCommon maintenance operations', '2015-05-13', '09:00:00', NULL, 'Damon LaCaille', NULL, 'Over the past 20 years Damon has held roles in consulting, management, technology and sales at companies such as Sun Microsystems, Sprint Paranet, Digi International and SailPoint Technologies. Damon is also a veteran of the U.S. Air Force', NULL, 13, 'http://www.mongodb.com/webinar/managing-mission-critical-app-downtime', 'http://www.mongodb.com/webinar/managing-mission-critical-app-downtime', NULL, '2015-05-10 02:53:24', '2015-05-10 02:53:24', 1, '', 0, NULL),
(13, ' When to Use MongoDB', 'When it comes time to select database software for your project, there are a bewildering number of choices. How do you know if your project is a good fit for a relational database, or whether one of the many NoSQL options is a better choice?\r\n\r\nIn this webinar you will learn when to use MongoDB and how to evaluate if MongoDB is a fit for your project. You will see how MongoDB''s flexible document model is solving business problems in ways that were not previously possible, and how MongoDB''s built-in features allow running at scale.\r\n\r\nTopics Covered Include:\r\n\r\nPerformance and Scalability\r\nMongoDB''s Data Model\r\nPopular MongoDB Use Cases\r\nCustomer Stories', '2015-05-19', '09:00:00', NULL, 'Edouard Servan-Schreiber', NULL, 'Dr. Edouard Servan-Schreiber is Director for Solution Architecture at MongoDB, advising customers on how to make MongoDB make their business simpler, faster, and better. Previously, Edouard was director for cross-channel analytics at Teradata, leading projects in advanced analytics and predictive modeling with customers in all heavily data-driven industries such as telco, retail, finance, high tech manufacturing. Edouard''s specialty is to help customers extract business value from their data through the wise use of technology. Edouard began practicing artificial intelligence and statistical learning models at Carnegie Mellon University for his bachelor''s degree, before going to UC Berkeley for his PhD in Computer Science', NULL, 13, 'http://www.mongodb.com/webinar/when-to-use-mongodb', 'http://www.mongodb.com/webinar/when-to-use-mongodb', NULL, '2015-05-10 12:42:39', '2015-05-10 12:42:39', 1, '', 0, NULL),
(14, ' Scaling MongoDB', 'Has your app taken off? Are you thinking about scaling? MongoDB makes it easy to horizontally scale out with built-in automatic sharding, but did you know that sharding isn''t the only way to achieve scale with MongoDB?\r\n\r\nIn this webinar, we''ll review three different ways to achieve scale with MongoDB. We''ll cover how you can optimize your application design and configure your storage to achieve scale, as well as the basics of horizontal scaling. You''ll walk away with a thorough understanding of options to scale your MongoDB application.\r\n\r\nTopics Covered Include:\r\n\r\nScaling Vertically\r\nHardware Considerations\r\nIndex Optimization\r\nSchema Design\r\nSharding', '2015-05-27', '00:00:00', NULL, 'Thomas Boyd', NULL, 'Thomas is the Director of Solutions Architecture for MongoDB where he helps customers with all things MongoDB including cluster setup, schema design, and performance tuning.  Before joining MongoDB, Thomas worked at Oracle and Hewlett-Packard and co-founded OuterBay Technologies, a data management company later acquired by HP.  When not helping customers succeed with MongoDB, Thomas enjoys the occasional soccer game and spending time with his family in the beautiful San Francisco Bay Area.', NULL, 13, 'http://www.mongodb.com/webinar/scaling-mongodb-may-2015', 'http://www.mongodb.com/webinar/scaling-mongodb-may-2015', NULL, '2015-05-10 12:42:09', '2015-05-10 12:42:09', 1, '', 0, NULL),
(18, 'NULL', 'NULL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2015-05-10 03:22:17', NULL, 0, NULL, 0, NULL),
(120, 'AWS Government, Education, and Nonprofits Symposium | Canberra', 'This complimentary event targets government, education, and nonprofit leaders and technical professionals seeking an introduction to the AWS Cloud, advanced guidance on architecture and engineering, opportunities to share and exchange ideas, and partners looking to build business relationships.', '2015-05-06', '09:12:00', NULL, 'Teresa Carlson', NULL, NULL, NULL, 3, 'https://aws.amazon.com/events/aws-gov-canberra/', 'https://aws.amazon.com/events/aws-gov-canberra/', NULL, '2015-05-10 12:21:31', NULL, 1, 'Vice President - Worldwide Public Sector, Amazon Web Services', 0, NULL),
(121, 'AWSome Day | Dallas', 'AWSome Day is based on the AWS Essentials training course and will take you through a step-by-step introduction to the core AWS services for compute, storage, database and networking.', '2015-04-21', '09:00:00', NULL, NULL, NULL, NULL, NULL, 3, 'http://aws.amazon.com/events/awsome-day/dallas/?sc_ichannel=lk&sc_icountry=na&ipage=events&sc_icampaign=AWSome15DFW&sc_icampaigntype=event&sc_isegment=pagevisist&trk=AWSome15DFW_lk_awsevents&trkCampaign=AWSome15DFW', 'http://aws.amazon.com/events/awsome-day/dallas/?sc_ichannel=lk&sc_icountry=na&ipage=events&sc_icampaign=AWSome15DFW&sc_icampaigntype=event&sc_isegment=pagevisist&trk=AWSome15DFW_lk_awsevents&trkCampaign=AWSome15DFW', NULL, '2015-05-10 12:24:12', NULL, 1, NULL, 0, NULL),
(122, 'AWS Bagels and Bytes | Netherlands | May', 'This free breakfast session will be delivered by AWS experts on a variety of topics and solutions provided by Amazon Web Services. Our theme for the May Session will be entitled "AWS and Enterprise".', '2015-05-19', '10:00:00', NULL, 'Zubin Chagpar', NULL, NULL, NULL, 3, 'https://aws.amazon.com/benelux/nl/bagels-and-bytes/may/?sc_ichannel=lk&sc_icountry=nl&sc_icampaign=bagelsandbytes_nl_2015&sc_icampaigntype=event&sc_ipage=events_landingpage&trk=lk_bb_events&trkCampaign=awsbb_bnl_nl_201505', 'https://aws.amazon.com/benelux/nl/bagels-and-bytes/may/?sc_ichannel=lk&sc_icountry=nl&sc_icampaign=bagelsandbytes_nl_2015&sc_icampaigntype=event&sc_ipage=events_landingpage&trk=lk_bb_events&trkCampaign=awsbb_bnl_nl_201505', NULL, '2015-05-10 12:26:12', NULL, 1, 'Venture Capital Business Development, EMEA', 0, NULL),
(123, 'Amazon S3 ', 'Amazon S3 hosts over 2 trillion objects and is used for storing a wide range of data, from system backups, web site assets and digital media. This webinar we will explain the features of Amazon S3 from static website hosting, through server side encryption to Amazon Glacier integration.', '2015-05-20', '11:00:00', NULL, NULL, NULL, NULL, NULL, 3, 'https://connect.awswebcasts.com/amazon-s3-20-may-2015/event/event_info.html?campaign-id=EP', 'https://connect.awswebcasts.com/amazon-s3-20-may-2015/event/event_info.html?campaign-id=EP', NULL, '2015-05-10 14:15:55', '2015-05-10 14:15:55', 1, NULL, 1, NULL),
(124, 'AWS Online Office Hours with Solutions Architects ', 'The Solutions Architect (SA) Online Office Hours hours are designed to answer Cloud Computing questions from the comfort of your own home. Questions can be asked in advance during the registration process, and we will give time for drop-in questions at the end of each session.', '2015-05-28', '10:00:00', NULL, NULL, NULL, NULL, NULL, 3, 'https://connect.awswebcasts.com/saoh0515/event/registration.html?campaign-id=EP', 'https://connect.awswebcasts.com/saoh0515/event/registration.html?campaign-id=EP', NULL, '2015-05-10 12:29:49', NULL, 1, NULL, 0, NULL),
(125, 'Cisco UCS Mini Architecture Webcast May 12', NULL, '2015-05-12', '11:30:00', NULL, NULL, NULL, NULL, NULL, 26, 'http://tools.cisco.com/gems/cust/customerQA.do?METHOD=E&LANGUAGE_ID=E&SEMINAR_CODE=S22784&PRIORITY_CODE=000565685', 'http://tools.cisco.com/gems/cust/customerQA.do?METHOD=E&LANGUAGE_ID=E&SEMINAR_CODE=S22784&PRIORITY_CODE=000565685', NULL, '2015-05-10 14:12:45', '2015-05-10 14:12:45', 1, NULL, 0, NULL),
(126, 'See How Big Data Creates Value', 'Companies in every industry look for ways to explore new data types and large data sets that were previously too big to capture, store and process. They need to unlock insights from data such as clickstream, geo-location, sensor, server log, social, text and video data. However, becoming a data-first enterprise comes with many challenges.', '2015-04-08', '14:00:00', NULL, 'i Bajwa, Hortonworks - Irshad Raihan, Red Hat - Ron Graham,', NULL, NULL, NULL, 26, 'https://www.brighttalk.com/webcast/9573/151529?utm_partnersource=Cisco', 'https://www.brighttalk.com/webcast/9573/151529?utm_partnersource=Cisco', NULL, '2015-05-10 12:37:05', NULL, 1, NULL, 0, NULL),
(127, 'TIBCO Jaspersoft Product Direction - North America', NULL, '2015-03-10', '09:30:00', NULL, 'Tom Tortolani', NULL, NULL, NULL, 28, 'https://www.jaspersoft.com/event/tibco-jaspersoft-product-direction-north-america', 'https://www.jaspersoft.com/event/tibco-jaspersoft-product-direction-north-america', NULL, '2015-05-10 12:41:00', NULL, 1, ' Head of Product Management, TIBCO Jaspersoft', 0, NULL),
(128, 'Leveraging Your Application for Data & Reporting Success with MongoDB and Kansys', 'Kansys, Inc. deploys TIBCO Jaspersoft with MongoDB to create a dynamic system to capture, analyze, and derive insights for their telecommunications carrier clients', '2015-04-07', '08:00:00', NULL, 'Robert Mills,Bing Wang', NULL, NULL, NULL, 29, 'https://www.jaspersoft.com/event/leveraging-your-application-data-management-success-mongodb-and-kansys-mongodb', 'https://www.jaspersoft.com/event/leveraging-your-application-data-management-success-mongodb-and-kansys-mongodb', NULL, '2015-05-10 12:55:42', NULL, 1, 'Senior Software Architect, Kansys, Inc', 0, NULL),
(129, ' Big Data for Defense and National Security: Maintaining the U.S. Technological Edge`', 'Webinar: \r\nBig Data for Defense and National Security: Maintaining the U.S. Technological Edge', '2015-05-12', '11:00:00', NULL, 'Amsterdam,', NULL, NULL, NULL, 30, 'https://www.eventbrite.com/e/rebroadcast-big-data-for-defense-and-national-security-maintaining-the-us-technological-edge-registration-16147658080', 'https://www.eventbrite.com/e/rebroadcast-big-data-for-defense-and-national-security-maintaining-the-us-technological-edge-registration-16147658080', NULL, '2015-05-10 14:10:15', '2015-05-10 14:10:15', 1, NULL, 0, NULL),
(130, 'MESA HITS – Hollywood IT Summit', NULL, '2015-05-14', NULL, NULL, 'Dean Hallett,Jane Greenberg, ', NULL, NULL, NULL, 30, 'http://www.hollywooditsociety.com/spring2015/', 'http://www.hollywooditsociety.com/spring2015/', NULL, '2015-05-10 15:41:43', '2015-05-10 15:41:43', 1, 'Fox Filmed Entertainment', 1, NULL),
(131, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2015-05-10 14:12:18', NULL, 0, NULL, 0, NULL),
(132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2015-05-10 14:12:24', NULL, 0, NULL, 0, NULL),
(135, ' Best Practices for Upgrading to MongoDB 3.0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 13, 'http://www.mongodb.com/webinar/upgrading-mongodb', 'http://www.mongodb.com/webinar/upgrading-mongodb', NULL, '2015-05-15 14:39:26', NULL, 1, NULL, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `do_webinar_category`
--

CREATE TABLE IF NOT EXISTS `do_webinar_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `webinar_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `webinar_id` (`webinar_id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=82 ;

--
-- Dumping data for table `do_webinar_category`
--

INSERT INTO `do_webinar_category` (`id`, `webinar_id`, `category_id`) VALUES
(18, 7, 12),
(41, 12, 2),
(42, 12, 4),
(43, 12, 6),
(56, 120, 1),
(57, 120, 2),
(58, 121, 1),
(59, 121, 2),
(60, 121, 8),
(61, 122, 1),
(62, 122, 2),
(65, 124, 1),
(66, 124, 2),
(70, 126, 1),
(71, 126, 2),
(72, 126, 4),
(73, 127, 5),
(74, 127, 6),
(75, 127, 8),
(77, 14, 4),
(78, 13, 4),
(79, 128, 5),
(80, 128, 6),
(81, 128, 8);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
